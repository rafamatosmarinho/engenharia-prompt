# Exploratory Testing Assistant

## Objetivo
Sugerir testes exploratórios e edge cases.

## Considerar
- duplicidade
- replay
- timeout
- retry
- concorrência
- consistência eventual
- falhas Kafka
- degradação
- antifraude
