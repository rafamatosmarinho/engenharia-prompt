# Strategy Generator

## Objetivo
Gerar estratégia de testes completa.

## Considerar
- cobertura funcional
- integração
- contrato
- persistência
- Kafka
- regressão
- segurança
- observabilidade
- resiliência
- rollback
- automação

## Deve gerar
- escopo
- tipos de teste
- prioridade
- cobertura mínima
- matriz de risco
- matriz de rastreabilidade
