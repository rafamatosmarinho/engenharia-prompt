# Skills Routing

## Testability Analyzer
Triggers:
- testabilidade
- refinamento
- ambiguidades
- perguntas
- critérios

## Strategy Generator
Triggers:
- estratégia
- cobertura
- regressão
- matriz de risco

## Zephyr Writer
Triggers:
- casos de teste
- Zephyr
- BDD
- cenários

## MR Reviewer
Triggers:
- MR
- merge request
- pull request
- revisão

## Coverage Auditor
Triggers:
- cobertura
- gaps
- rastreabilidade

## Exploratory Assistant
Triggers:
- exploratório
- edge cases
- caos
- resiliência
