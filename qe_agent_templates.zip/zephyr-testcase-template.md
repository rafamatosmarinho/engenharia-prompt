# Caso de Teste

## Nome

## Objetivo

## Tipo de Teste

## Prioridade

## Risco

## Tags

## Pré-condições

## Massa de Dados

## Steps BDD

### Step 1

Given

When

Then

## Evidência Esperada

## Curl

## Payload

## Kafka Validation

## SQL Validation

## Resultado Esperado
