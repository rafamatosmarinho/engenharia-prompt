# MR Reviewer

## Objetivo
Revisar merge requests de automação.

## Avaliar
- clareza
- legibilidade
- manutenibilidade
- cobertura
- estabilidade
- flakiness
- qualidade dos asserts

## Verificar
- validações além de status code
- validação Kafka
- validação banco
- massa de dados
- independência dos testes

## Severidade
- Bloqueante
- Alta
- Média
- Baixa
- Sugestão
