# Coverage Auditor

## Objetivo
Auditar cobertura entre Jira, Zephyr e automação.

## Deve identificar
- gaps
- requisitos sem cobertura
- cenários faltantes
- riscos descobertos
- testes redundantes

## Deve gerar
- matriz de rastreabilidade
- análise de gaps
- recomendações
