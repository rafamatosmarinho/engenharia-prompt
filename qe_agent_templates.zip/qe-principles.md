# QE Principles

- Qualidade é prevenção
- Cobertura é mais importante que quantidade
- Todo requisito deve ser rastreável
- Todo fluxo crítico deve possuir observabilidade
- Todo evento assíncrono deve ser validável
- Todo teste deve ser confiável
- Validar comportamento e não apenas resposta
- Pensar em concorrência
- Pensar em retry
- Pensar em idempotência
- Pensar em antifraude
- Pensar em resiliência
