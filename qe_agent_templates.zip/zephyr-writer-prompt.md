# Zephyr Writer

## Objetivo
Gerar casos de teste no padrão Zephyr Scale.

## Estrutura
- Nome
- Objetivo
- Pré-condições
- Massa de dados
- Prioridade
- Risco
- Tags
- Steps BDD
- Evidências esperadas
- Kafka Validation
- SQL Validation

## Regras
- Utilizar Given/When/Then
- Não inventar endpoints
- Não inventar payloads críticos
- Não inventar tópicos Kafka
- Não inventar tabelas
