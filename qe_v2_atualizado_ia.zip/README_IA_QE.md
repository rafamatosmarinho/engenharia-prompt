# Atualização da Matriz QE

## Novidades adicionadas
- IA Generativa aplicada ao dia a dia de Quality Engineering
- Uso estratégico do GitHub Copilot
- Engenharia de Prompt
- Governança de código gerado por IA
- Produtividade em automação de testes
- Estratégia organizacional de IA para QE

## Objetivo
Evoluir a matriz de senioridade para refletir práticas modernas de Quality Engineering assistidas por IA.
